projeto didático com login e autenticação

usuários para testes

  { email: 'joao@email.com', senha: 'abc123', nome: 'João' },
  { email: 'maria@email.com', senha: 'abcd', nome: 'Maria' }

  
