const express = require('express');
const cookieParser = require('cookie-parser');
const app = express();
const port = 3001;

app.use(express.json());
app.use(cookieParser());

// Substitua o middleware CORS atual por este:
app.use((req, res, next) => {
    const allowedOrigins = ['http://localhost:3000', 'http://127.0.0.1:5500'];
    const origin = req.headers.origin;

    if (allowedOrigins.includes(origin)) {
        res.header('Access-Control-Allow-Origin', origin);
    }

    res.header('Access-Control-Allow-Methods', 'GET, POST');
    res.header('Access-Control-Allow-Headers', 'Content-Type');
    res.header('Access-Control-Allow-Credentials', 'true');
    next();
});


// Middleware CORS
// app.use((req, res, next) => {
//     res.header('Access-Control-Allow-Origin', 'http://localhost:3000');
//     res.header('Access-Control-Allow-Methods', 'GET, POST');
//     res.header('Access-Control-Allow-Headers', 'Content-Type');
//     res.header('Access-Control-Allow-Credentials', 'true');
//     next();
// });

// Lista de usuários
const usuarios = [
    { email: 'joao@email.com', senha: '1234', nome: 'João', tipo: 'admin' },
    { email: 'maria@email.com', senha: 'abcd', nome: 'Maria', tipo: 'comum' }
];

// Middleware para verificar login
const checkAuth = (req, res, next) => {
    if (req.cookies.logado) {
        next();
    } else {
        res.status(401).send('Não autorizado');
    }
};

// Rota de login
app.post('/login', (req, res) => {
    const { email, senha } = req.body;
    const usuario = usuarios.find(u => u.email === email && u.senha === senha);

    if (usuario) {
        res.cookie('logado', 'true', { maxAge: 900000, httpOnly: true });
        res.send({ success: true, nome: usuario.nome });
    } else {
        res.status(401).send({ success: false, message: 'Email ou senha inválidos' });
    }
});

// Rota de logout
app.post('/logout', (req, res) => {
    res.clearCookie('logado');
    res.send({ success: true });
});

// Rota protegida para verificar autenticação
app.get('/check-auth', checkAuth, (req, res) => {
    res.send({ authenticated: true });
});

app.listen(port, () => {
    console.log(`Servidor rodando em http://localhost:${port}`);
});